/* ============================================
   GOLDEN VISA CHECK — QUIZ ENGINE
   All quiz logic. No external dependencies.
============================================ */

const QUIZ_CONFIG = {
  steps: [
    {
      id: "intent",
      question: "What best describes you?",
      subtitle: "We'll tailor the check to your profile.",
      type: "single",
      options: [
        { value: "investor",       label: "Property Investor",                     emoji: "🏢", points: { golden: 20, green: 0,  blue: 0  } },
        { value: "professional",   label: "Employed Professional",                 emoji: "💼", points: { golden: 15, green: 10, blue: 0  } },
        { value: "freelancer",     label: "Freelancer / Self-Employed",            emoji: "💻", points: { golden: 0,  green: 20, blue: 0  } },
        { value: "sustainability", label: "Environmental / Sustainability Expert", emoji: "🌿", points: { golden: 0,  green: 0,  blue: 25 } }
      ]
    },
    {
      id: "residency",
      question: "What is your current residency status?",
      subtitle: "This determines your processing track.",
      type: "single",
      options: [
        { value: "uae_resident", label: "UAE Resident (active visa)", emoji: "🇦🇪", points: { golden: 10, green: 10, blue: 10 } },
        { value: "gcc_national", label: "GCC National",               emoji: "🌍", points: { golden: 15, green: 15, blue: 15 } },
        { value: "overseas",     label: "Based Overseas",             emoji: "✈️", points: { golden: 5,  green: 5,  blue: 5  } },
        { value: "tourist",      label: "Currently on Visit Visa",    emoji: "🛂", points: { golden: 5,  green: 5,  blue: 5  } }
      ]
    },
    {
      id: "financial",
      question: "What is your primary financial qualification?",
      subtitle: "Select the option that best matches your situation.",
      type: "single",
      options: [
        { value: "property_2m_plus",  label: "UAE property worth AED 2M or more",            emoji: "🏙️", points: { golden: 35, green: 0,  blue: 0  } },
        { value: "property_1m_2m",    label: "UAE property between AED 1M – 2M",             emoji: "🏠", points: { golden: 15, green: 0,  blue: 0  } },
        { value: "salary_30k_plus",   label: "Monthly salary AED 30,000+ (MoHRE L1/L2)",    emoji: "💰", points: { golden: 30, green: 10, blue: 0  } },
        { value: "salary_15k_30k",    label: "Monthly salary AED 15,000 – 29,999",           emoji: "💵", points: { golden: 0,  green: 25, blue: 0  } },
        { value: "freelance_360k",    label: "Annual freelance income AED 360,000+",          emoji: "📈", points: { golden: 0,  green: 30, blue: 0  } },
        { value: "freelance_below",   label: "Annual freelance income below AED 360,000",     emoji: "📉", points: { golden: 0,  green: 10, blue: 0  } },
        { value: "env_1m_plus",       label: "Environmental contribution / investment AED 1M+",emoji: "🌱", points: { golden: 0,  green: 0,  blue: 35 } },
        { value: "env_role",          label: "Accredited sustainability / environmental role", emoji: "♻️", points: { golden: 0,  green: 0,  blue: 25 } }
      ]
    },
    {
      id: "documents",
      question: "Which documents do you currently have?",
      subtitle: "Select all that apply.",
      type: "multi",
      options: [
        { value: "title_deed",           label: "UAE Property Title Deed",              emoji: "📄", points: { golden: 8, green: 0, blue: 0 } },
        { value: "payslips",             label: "3 months payslips",                    emoji: "🧾", points: { golden: 5, green: 5, blue: 0 } },
        { value: "employment_contract",  label: "Employment contract (MoHRE attested)", emoji: "📋", points: { golden: 5, green: 5, blue: 0 } },
        { value: "trade_license",        label: "UAE Trade / Freelance License",        emoji: "🏪", points: { golden: 0, green: 8, blue: 0 } },
        { value: "bank_statements",      label: "6 months bank statements",             emoji: "🏦", points: { golden: 4, green: 4, blue: 4 } },
        { value: "env_cert",             label: "Environmental accreditation",           emoji: "🌿", points: { golden: 0, green: 0, blue: 10} },
        { value: "none",                 label: "None yet — just starting",             emoji: "📭", points: { golden: 0, green: 0, blue: 0 } }
      ]
    },
    {
      id: "timeline",
      question: "When are you looking to apply?",
      subtitle: "Urgency helps us prioritize your case.",
      type: "single",
      options: [
        { value: "immediate",   label: "Immediately — my visa is expiring soon", emoji: "🔥", urgency: "high",   points: { golden: 15, green: 15, blue: 15 } },
        { value: "1_3_months",  label: "Within 1 – 3 months",                   emoji: "📅", urgency: "medium", points: { golden: 10, green: 10, blue: 10 } },
        { value: "3_6_months",  label: "3 – 6 months from now",                 emoji: "🗓️", urgency: "low",    points: { golden: 5,  green: 5,  blue: 5  } },
        { value: "exploring",   label: "Just exploring options",                 emoji: "🔍", urgency: "cold",   points: { golden: 0,  green: 0,  blue: 0  } }
      ]
    }
  ]
};

const PARTNER_WHATSAPP = "971552678457";

const CHECKLISTS = {
  golden: {
    property_investor: [
      { label: "UAE Property Title Deed", key: "title_deed" },
      { label: "Mortgage statement (if applicable)", key: "mortgage" },
      { label: "Valid passport", key: "passport" },
      { label: "Emirates ID (if resident)", key: "eid" },
      { label: "Recent passport-size photos", key: "photos" }
    ],
    professional: [
      { label: "Employment contract (MoHRE Level 1 or 2 attested)", key: "employment_contract" },
      { label: "3 months payslips", key: "payslips" },
      { label: "6 months bank statements", key: "bank_statements" },
      { label: "Valid passport", key: "passport" },
      { label: "Emirates ID (if resident)", key: "eid" }
    ]
  },
  green: [
    { label: "UAE Freelance / Trade License", key: "trade_license" },
    { label: "Proof of income (invoices or payslips)", key: "payslips" },
    { label: "6 months bank statements", key: "bank_statements" },
    { label: "Valid passport", key: "passport" },
    { label: "Health insurance", key: "insurance" }
  ],
  blue: [
    { label: "Environmental accreditation / certification", key: "env_cert" },
    { label: "Proof of AED 1M+ contribution (if applicable)", key: "contribution" },
    { label: "Letter from accredited institution", key: "letter" },
    { label: "Valid passport", key: "passport" },
    { label: "6 months bank statements", key: "bank_statements" }
  ]
};

// ============ QUIZ STATE ============
let state = {
  currentStep: 0,
  answers: {},
  multiSelections: []
};

function calculateScore(answers) {
  const scores = { golden: 0, green: 0, blue: 0 };
  for (const [stepId, answer] of Object.entries(answers)) {
    const step = QUIZ_CONFIG.steps.find(s => s.id === stepId);
    if (!step) continue;
    const values = Array.isArray(answer) ? answer : [answer];
    values.forEach(val => {
      const opt = step.options.find(o => o.value === val);
      if (opt) {
        scores.golden += opt.points.golden || 0;
        scores.green  += opt.points.green  || 0;
        scores.blue   += opt.points.blue   || 0;
      }
    });
  }
  const primary = Object.entries(scores).sort((a,b) => b[1]-a[1])[0][0];
  const topScore = scores[primary];
  const tier = topScore >= 70 ? 'A' : topScore >= 40 ? 'B' : 'C';
  return { scores, primary, topScore, tier };
}

function getChecklist(answers, primary) {
  if (primary === 'golden') {
    return answers.intent === 'investor' ? CHECKLISTS.golden.property_investor : CHECKLISTS.golden.professional;
  }
  if (primary === 'green') return CHECKLISTS.green;
  return CHECKLISTS.blue;
}

function renderQuiz() {
  const container = document.getElementById('quiz-container');
  if (!container) return;

  const totalSteps = QUIZ_CONFIG.steps.length + 1;
  const progress = ((state.currentStep + 1) / totalSteps) * 100;

  if (state.currentStep < QUIZ_CONFIG.steps.length) {
    const step = QUIZ_CONFIG.steps[state.currentStep];
    const isMulti = step.type === 'multi';
    const currentAnswer = state.answers[step.id];
    const currentMulti = state.multiSelections;

    container.innerHTML = `
      <div class="quiz-top-bar">
        <div class="quiz-progress" style="width: ${progress}%"></div>
      </div>
      <div class="quiz-header">
        <div class="quiz-step-label">Step ${state.currentStep + 1} of ${totalSteps}</div>
        <div class="quiz-question">${step.question}</div>
        <div class="quiz-subtitle">${step.subtitle}</div>
      </div>
      <div class="quiz-body">
        <div class="quiz-options" id="quiz-options">
          ${step.options.map(opt => `
            <button class="quiz-option ${isMulti ? (currentMulti.includes(opt.value) ? 'multi-selected' : '') : (currentAnswer === opt.value ? 'selected' : '')}"
              data-value="${opt.value}"
              onclick="${isMulti ? 'toggleMulti(this)' : `selectSingle('${step.id}', '${opt.value}', this)`}">
              <span class="option-emoji">${opt.emoji}</span>
              <span>${opt.label}</span>
              <span class="option-check">${(isMulti ? currentMulti.includes(opt.value) : currentAnswer === opt.value) ? '✓' : ''}</span>
            </button>
          `).join('')}
        </div>
        <div class="quiz-nav">
          ${state.currentStep > 0 ? `<button class="quiz-back" onclick="goBack()">← Back</button>` : ''}
          ${isMulti ? `<button class="quiz-next" id="multi-next" onclick="submitMulti('${step.id}')" ${currentMulti.length === 0 ? 'disabled' : ''}>Continue →</button>` : ''}
        </div>
      </div>
    `;
  } else {
    // Contact form step
    container.innerHTML = `
      <div class="quiz-top-bar">
        <div class="quiz-progress" style="width: 95%"></div>
      </div>
      <div class="quiz-header">
        <div class="quiz-step-label">Final Step</div>
        <div class="quiz-question">Where should we send your report?</div>
        <div class="quiz-subtitle">Free. No spam. Your eligibility score + personalized document checklist.</div>
      </div>
      <div class="quiz-body">
        <form class="quiz-contact-form" id="lead-form" onsubmit="submitLead(event)">
          <input class="quiz-input" type="text" name="full_name" placeholder="Full Name" required autocomplete="name">
          <input class="quiz-input" type="tel" name="whatsapp" placeholder="WhatsApp Number (e.g. +971 50 123 4567)" required autocomplete="tel">
          <input class="quiz-input" type="email" name="email" placeholder="Email Address" required autocomplete="email">
          <p class="quiz-consent">By submitting you agree to be contacted by Golden Visa Check's verified partner network including licensed UAE immigration lawyers and specialists.</p>
          <button class="quiz-submit" type="submit" id="submit-btn">Get My Free Eligibility Report →</button>
        </form>
        <div class="quiz-nav" style="margin-top: 12px">
          <button class="quiz-back" onclick="goBack()">← Back</button>
        </div>
      </div>
    `;
  }
}

function selectSingle(stepId, value, btn) {
  state.answers[stepId] = value;
  document.querySelectorAll('.quiz-option').forEach(b => {
    b.classList.remove('selected');
    b.querySelector('.option-check').textContent = '';
  });
  btn.classList.add('selected');
  btn.querySelector('.option-check').textContent = '✓';
  setTimeout(() => {
    state.currentStep++;
    renderQuiz();
  }, 300);
}

function toggleMulti(btn) {
  const val = btn.dataset.value;
  if (val === 'none') {
    state.multiSelections = ['none'];
    document.querySelectorAll('.quiz-option').forEach(b => {
      b.classList.remove('multi-selected');
      b.querySelector('.option-check').textContent = '';
    });
    btn.classList.add('multi-selected');
    btn.querySelector('.option-check').textContent = '✓';
  } else {
    state.multiSelections = state.multiSelections.filter(v => v !== 'none');
    if (state.multiSelections.includes(val)) {
      state.multiSelections = state.multiSelections.filter(v => v !== val);
      btn.classList.remove('multi-selected');
      btn.querySelector('.option-check').textContent = '';
    } else {
      state.multiSelections.push(val);
      btn.classList.add('multi-selected');
      btn.querySelector('.option-check').textContent = '✓';
    }
  }
  const nextBtn = document.getElementById('multi-next');
  if (nextBtn) nextBtn.disabled = state.multiSelections.length === 0;
}

function submitMulti(stepId) {
  state.answers[stepId] = [...state.multiSelections];
  state.multiSelections = [];
  state.currentStep++;
  renderQuiz();
}

function goBack() {
  if (state.currentStep > 0) {
    state.currentStep--;
    state.multiSelections = [];
    renderQuiz();
  }
}

async function submitLead(e) {
  e.preventDefault();
  const form = e.target;
  const btn = document.getElementById('submit-btn');
  btn.textContent = 'Calculating your score...';
  btn.disabled = true;

  const full_name = form.full_name.value.trim();
  const whatsapp  = form.whatsapp.value.trim();
  const email     = form.email.value.trim();
  const result    = calculateScore(state.answers);
  const checklist = getChecklist(state.answers, result.primary);

  // Submit to Netlify Forms
  try {
    const formData = new FormData();
    formData.append('form-name', 'visa-leads');
    formData.append('full_name', full_name);
    formData.append('whatsapp', whatsapp);
    formData.append('email', email);
    formData.append('visa_type', result.primary);
    formData.append('score', result.topScore);
    formData.append('tier', result.tier);
    formData.append('answers', JSON.stringify(state.answers));
    formData.append('scores', JSON.stringify(result.scores));
    formData.append('timeline', state.answers.timeline || 'unknown');

    await fetch('/', { method: 'POST', body: formData });
  } catch(err) {
    console.log('Form submission note:', err);
  }

  showResult(full_name, result, checklist);
}

function showResult(name, result, checklist) {
  const container = document.getElementById('quiz-container');
  const visaLabels = { golden: 'Golden Visa', green: 'Green Visa', blue: 'Blue Visa' };
  const visaColors = { golden: 'golden', green: 'green', blue: 'blue' };
  const score = result.topScore;

  let verdictClass, verdictIcon, verdictText;
  if (score >= 60) {
    verdictClass = 'strong'; verdictIcon = '✓'; verdictText = 'Strong Eligibility';
  } else if (score >= 40) {
    verdictClass = 'possible'; verdictIcon = '◑'; verdictText = 'Possible Eligibility';
  } else {
    verdictClass = 'review'; verdictIcon = '→'; verdictText = 'Needs Further Review';
  }

  const waText = encodeURIComponent(`Hi, I just scored ${score}/100 on GoldenVisaCheck.ae. My recommended visa is the ${visaLabels[result.primary]}. Can you help me with my application?`);
  const waUrl = `https://wa.me/${PARTNER_WHATSAPP}?text=${waText}`;

  const docsHave = Array.isArray(state.answers.documents) ? state.answers.documents : [];

  container.innerHTML = `
    <div class="quiz-top-bar">
      <div class="quiz-progress" style="width: 100%"></div>
    </div>
    <div class="result-card">
      <div class="result-verdict">
        <div class="verdict-icon">${verdictIcon}</div>
        <div class="verdict-label ${verdictClass}">${verdictText}</div>
        <div class="verdict-score">Eligibility Score: <strong>${score} / 100</strong> · Tier ${result.tier}</div>
        <span class="verdict-visa-badge visa-badge ${visaColors[result.primary]}">${visaLabels[result.primary]}</span>
      </div>
      <div class="result-body">
        <div class="result-checklist">
          <h4>Your Document Checklist</h4>
          ${checklist.map(item => `
            <div class="checklist-item">
              <div class="check-dot ${docsHave.includes(item.key) ? 'done' : 'todo'}">${docsHave.includes(item.key) ? '✓' : '!'}</div>
              <span>${item.label}</span>
            </div>
          `).join('')}
        </div>
        <a href="${waUrl}" target="_blank" rel="noopener" class="result-wa-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
          Speak to a Visa Specialist
        </a>
        <p class="result-disclaimer">A specialist will contact you within 2 hours. Golden Visa Check is an independent eligibility tool — results are indicative only and do not constitute legal advice.</p>
      </div>
    </div>
  `;
}

// ============ INIT ============
document.addEventListener('DOMContentLoaded', () => {
  renderQuiz();

  // Hamburger menu
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('nav-mobile');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => mobileNav.classList.toggle('open'));
  }

  // FAQ accordion
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.parentElement;
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  // Navbar scroll effect
  window.addEventListener('scroll', () => {
    const nav = document.getElementById('navbar');
    if (nav) nav.classList.toggle('scrolled', window.scrollY > 20);
  });
});
